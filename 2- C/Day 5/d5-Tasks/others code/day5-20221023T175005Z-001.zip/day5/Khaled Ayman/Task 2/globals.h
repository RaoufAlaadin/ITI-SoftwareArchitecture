#define NormalPen 0x0F
#define HighLightPen 0XF0
#define Enter 0x0D
#define ESC 0x1B
#define UP 0xE048
#define DOWN 0xE050
#define MAIN_MENU_SIZE 3